# Breadline brand treatments

Eight standalone SVGs, each `viewBox="0 0 128 128"`. All typography is outlined; no raster images, scripts, remote resources or fonts. The cream rim is decorative: operational status belongs outside the asset.

- `7eleven.svg`: existing vector identity with a quieter orange/red/green palette and normalized framing. Source: https://www.7-eleven.hk/themes/custom/seven_eleven/logo.svg
- `maxims.svg`: newly drawn cocoa rose inspired by Maxim’s Cakes, replacing the low-resolution crop. Source identity: https://www.maximscakes.com.hk/en
- `arome.svg`: olive/cream egg treatment, from the user-supplied older arôme wordmark reference.
- `honore.svg`: rounded chef-outline interpretation of the Saint Honore app icon supplied by the user.
- `yamazaki.svg`: complete wheat device, geometrically centred and recoloured ochre. Paths from the official Hong Kong website header: https://www.yamazaki.hk/
- `kayser.svg`: negative cream monogram on forest green, using the original oval and K/e paths. Source: https://maison-kayser.com/wp-content/themes/kayser/images/logo_mobile.svg
- `peninsula.svg`: custom outlined serif P based on the website favicon reference supplied by the user.
- `garden.svg`: simplified chef mark based on the user-supplied Garden reference, on berry red.

These are app-specific treatments, not official replacement brand masters. Preview and 48/32 px checks: `output/breadline-brand-review/v2/treatments.png`. The current brand resolver is unchanged pending design review.
